import json
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"
DATA_FILE = DATA_DIR / "sessions.json"


def default_data():
    return {
        "daily_goal_minutes": 480,
        "sessions": []
    }


def load_data():
    DATA_DIR.mkdir(exist_ok=True)
    if not DATA_FILE.exists():
        data = default_data()
        save_data(data)
        return data

    try:
        with DATA_FILE.open("r", encoding="utf-8") as file:
            data = json.load(file)
        if not isinstance(data, dict):
            return default_data()
        data.setdefault("daily_goal_minutes", 480)
        data.setdefault("sessions", [])
        return data
    except (json.JSONDecodeError, OSError):
        return default_data()


def save_data(data):
    DATA_DIR.mkdir(exist_ok=True)
    with DATA_FILE.open("w", encoding="utf-8") as file:
        json.dump(data, file, indent=4)
