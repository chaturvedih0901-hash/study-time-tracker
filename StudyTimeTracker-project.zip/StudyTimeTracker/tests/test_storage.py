import unittest
import tempfile
from pathlib import Path
from unittest.mock import patch
import storage


class TestStorage(unittest.TestCase):
    def test_default_data(self):
        data = storage.default_data()
        self.assertIn("sessions", data)
        self.assertIn("daily_goal_minutes", data)
        self.assertEqual(data["sessions"], [])

    def test_save_and_load(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "sessions.json"

            with patch.object(storage, "DATA_DIR", Path(temp)), \
                 patch.object(storage, "DATA_FILE", path):
                original = {
                    "daily_goal_minutes": 300,
                    "sessions": [{"subject": "Math", "duration_minutes": 60}]
                }
                storage.save_data(original)
                loaded = storage.load_data()
                self.assertEqual(loaded, original)


if __name__ == "__main__":
    unittest.main()
