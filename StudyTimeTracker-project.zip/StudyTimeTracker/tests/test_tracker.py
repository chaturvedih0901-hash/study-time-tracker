import unittest
from datetime import datetime, date
from unittest.mock import patch
from tracker import StudyTracker


class TestTracker(unittest.TestCase):
    @patch("tracker.save_data")
    @patch("tracker.load_data")
    def test_start_session(self, mock_load, mock_save):
        mock_load.return_value = {"daily_goal_minutes": 480, "sessions": []}
        tracker = StudyTracker()
        tracker.start_session("Python", "Loops")

        self.assertIsNotNone(tracker.active_session)
        self.assertEqual(tracker.active_session["subject"], "Python")

    @patch("tracker.save_data")
    @patch("tracker.load_data")
    def test_stop_session(self, mock_load, mock_save):
        mock_load.return_value = {"daily_goal_minutes": 480, "sessions": []}
        tracker = StudyTracker()
        tracker.active_session = {
            "subject": "Python",
            "topic": "Loops",
            "start_time": datetime.now().isoformat(timespec="seconds")
        }

        result = tracker.stop_session()

        self.assertIsNotNone(result)
        self.assertEqual(result["subject"], "Python")
        self.assertGreaterEqual(result["duration_minutes"], 1)


if __name__ == "__main__":
    unittest.main()
