import unittest
from ui import format_minutes


class TestUI(unittest.TestCase):
    def test_format_minutes(self):
        self.assertEqual(format_minutes(45), "45m")
        self.assertEqual(format_minutes(90), "1h 30m")
        self.assertEqual(format_minutes(120), "2h 0m")


if __name__ == "__main__":
    unittest.main()
