# Project Statement

## Project Title
Study Time Tracker

## Problem Statement
Students often spend time studying without having a clear record of how much time they actually dedicate to each subject. A simple tracking system can help organize study sessions and provide useful summaries.

## Proposed Solution
Study Time Tracker is a Python console application that records study sessions, calculates duration, stores the information in JSON, and generates daily, subject-wise, and weekly summaries.

## Objectives
- Track study duration accurately.
- Organize sessions by subject and topic.
- Maintain persistent records.
- Set a daily study target.
- Provide simple progress analytics.
- Demonstrate modular Python programming.

## Expected Outcome
The final application provides students with a lightweight way to understand their study patterns and maintain a consistent study routine.
