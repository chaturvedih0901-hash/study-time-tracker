# 📚 Study Time Tracker

A Python 3 console application that helps students record study sessions, monitor daily goals, and review subject-wise and weekly study statistics.

## Features

- Start and stop study sessions
- Record subject and topic
- Automatically calculate session duration
- Store data persistently using JSON
- View today's study summary
- View complete study history
- View subject-wise statistics
- Set a daily study goal
- View a 7-day study report
- Input validation
- Automated unit tests

## Project Structure

```text
StudyTimeTracker/
├── main.py
├── tracker.py
├── storage.py
├── ui.py
├── data/
│   └── sessions.json
├── tests/
│   ├── test_tracker.py
│   ├── test_storage.py
│   └── test_ui.py
├── docs/
│   ├── architecture.md
│   ├── workflow.md
│   └── diagrams.md
├── README.md
├── statement.md
├── project_report.md
└── requirements.txt
```

## Requirements

Python 3.8 or newer.

No third-party packages are required.

## Run

```bash
python main.py
```

## Test

```bash
python -m unittest discover -s tests -v
```

## Concepts Demonstrated

- Functions
- Classes and objects
- Conditional statements
- Loops
- Lists and dictionaries
- Date and time handling
- JSON file handling
- Modules
- Exception handling
- Unit testing
