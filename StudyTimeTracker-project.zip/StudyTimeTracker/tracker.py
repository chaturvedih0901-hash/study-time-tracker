from datetime import datetime, date, timedelta
from storage import load_data, save_data


class StudyTracker:
    def __init__(self):
        self.data = load_data()
        self.active_session = None

    def start_session(self, subject, topic):
        if self.active_session is not None:
            raise RuntimeError("A study session is already running.")

        self.active_session = {
            "subject": subject,
            "topic": topic,
            "start_time": datetime.now().isoformat(timespec="seconds")
        }

    def stop_session(self):
        if self.active_session is None:
            return None

        start = datetime.fromisoformat(self.active_session["start_time"])
        end = datetime.now()
        seconds = max(0, int((end - start).total_seconds()))
        minutes = max(1, round(seconds / 60))

        session = {
            "date": str(date.today()),
            "subject": self.active_session["subject"],
            "topic": self.active_session["topic"],
            "start_time": self.active_session["start_time"],
            "end_time": end.isoformat(timespec="seconds"),
            "duration_minutes": minutes
        }

        self.data["sessions"].append(session)
        save_data(self.data)
        self.active_session = None
        return session

    def get_history(self):
        return list(reversed(self.data["sessions"]))

    def get_today_summary(self):
        today = str(date.today())
        sessions = [s for s in self.data["sessions"] if s["date"] == today]
        total = sum(s["duration_minutes"] for s in sessions)
        goal = self.data.get("daily_goal_minutes", 480)

        return {
            "date": today,
            "total_minutes": total,
            "goal_minutes": goal,
            "progress_percent": min(100, round(total / goal * 100)) if goal else 0,
            "sessions": sessions
        }

    def get_subject_stats(self):
        stats = {}
        for session in self.data["sessions"]:
            subject = session["subject"]
            stats.setdefault(subject, {"minutes": 0, "sessions": 0})
            stats[subject]["minutes"] += session["duration_minutes"]
            stats[subject]["sessions"] += 1
        return stats

    def set_daily_goal(self, minutes):
        self.data["daily_goal_minutes"] = minutes
        save_data(self.data)

    def get_weekly_report(self):
        today = date.today()
        report = []
        for i in range(6, -1, -1):
            current = today - timedelta(days=i)
            key = str(current)
            minutes = sum(
                s["duration_minutes"]
                for s in self.data["sessions"]
                if s["date"] == key
            )
            report.append({
                "date": key,
                "minutes": minutes
            })
        return report
