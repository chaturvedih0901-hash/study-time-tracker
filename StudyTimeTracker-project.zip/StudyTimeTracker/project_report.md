# STUDY TIME TRACKER
## Project Report

### 1. Introduction
- Study Time Tracker is a Python-based console application.
- It records study sessions and stores them for later analysis.
- The application is designed for students who want a simple productivity tracker.

### 2. Problem Statement
- Students may find it difficult to remember how much time they spent studying.
- Manual tracking can be inconsistent.
- Subject-wise and weekly patterns are difficult to identify without stored data.

### 3. Objectives
- Track study sessions.
- Calculate study duration.
- Maintain a study history.
- Monitor a daily goal.
- Display subject-wise statistics.
- Generate a weekly report.

### 4. Functional Requirements
- Start a study session.
- Stop a study session.
- Enter subject and topic.
- View today's total.
- View historical sessions.
- View subject statistics.
- Set a daily goal.
- View the last seven days.

### 5. Technology Used
- Python 3
- JSON
- `datetime`
- `unittest`
- Console interface

### 6. Architecture
- `main.py` controls the application workflow.
- `tracker.py` contains study-session logic.
- `storage.py` handles persistent JSON storage.
- `ui.py` handles interaction and display.

### 7. Data Storage
- Sessions are stored in `data/sessions.json`.
- JSON makes the data human-readable and easy to process.

### 8. Testing
- Unit tests cover session creation, session stopping, storage and formatting.
- Tests can be executed using Python's built-in `unittest` framework.

### 9. Challenges
- Handling an already-running session.
- Validating user input.
- Preserving data between program runs.
- Calculating elapsed time.

### 10. Learning Outcomes
- Modular programming.
- Object-oriented programming basics.
- File handling.
- JSON serialization.
- Date and time programming.
- Unit testing.

### 11. Future Scope
- Pomodoro timer.
- Login and multiple student profiles.
- Graphical user interface.
- CSV/PDF reports.
- Calendar integration.
- Reminders.
- More detailed productivity analytics.

### 12. Conclusion
- Study Time Tracker demonstrates how Python can be used to build a practical student productivity application.
- The modular design makes the project easy to extend with additional features.
