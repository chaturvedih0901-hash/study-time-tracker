def show_banner():
    print("\n" + "=" * 50)
    print("          📚 STUDY TIME TRACKER")
    print("        Track. Focus. Improve. 🚀")
    print("=" * 50)


def show_menu():
    print("""
╔════════════════════════════════════════════╗
║              MAIN MENU                     ║
╠════════════════════════════════════════════╣
║  1. ▶ Start Study Session                  ║
║  2. ⏹ Stop Study Session                   ║
║  3. 📊 Today's Study Time                  ║
║  4. 📅 Study History                       ║
║  5. 📚 Subject-wise Statistics             ║
║  6. 🎯 Set Daily Goal                      ║
║  7. 📈 Weekly Report                       ║
║  8. 🚪 Exit                                ║
╚════════════════════════════════════════════╝
""")


def get_choice():
    while True:
        choice = input("Enter your choice (1-8): ").strip()
        if choice in "12345678" and len(choice) == 1:
            return choice
        print("Please enter a number from 1 to 8.")


def get_subject():
    while True:
        subject = input("Enter subject: ").strip()
        if subject:
            return subject
        print("Subject cannot be empty.")


def get_topic():
    topic = input("Enter topic (optional): ").strip()
    return topic or "General"


def get_daily_goal():
    while True:
        try:
            minutes = int(input("Daily goal in minutes: "))
            if minutes > 0:
                return minutes
            print("Enter a positive number.")
        except ValueError:
            print("Please enter a valid number.")


def show_message(message):
    print(f"\n{message}\n")


def format_minutes(minutes):
    hours, mins = divmod(minutes, 60)
    if hours:
        return f"{hours}h {mins}m"
    return f"{mins}m"


def show_summary(summary):
    print("\n📊 TODAY'S STUDY SUMMARY")
    print("-" * 35)
    print(f"Date: {summary['date']}")
    print(f"Total study time: {format_minutes(summary['total_minutes'])}")
    print(f"Daily goal: {format_minutes(summary['goal_minutes'])}")
    print(f"Progress: {summary['progress_percent']}%")
    print(f"Sessions today: {len(summary['sessions'])}")


def show_history(history):
    print("\n📅 STUDY HISTORY")
    print("-" * 70)
    if not history:
        print("No study sessions recorded yet.")
        return

    for s in history:
        print(
            f"{s['date']} | {s['subject']:<15} | "
            f"{s['topic']:<20} | {s['duration_minutes']} min"
        )


def show_subject_stats(stats):
    print("\n📚 SUBJECT-WISE STATISTICS")
    print("-" * 45)
    if not stats:
        print("No data available yet.")
        return

    for subject, values in sorted(stats.items()):
        print(
            f"{subject:<20} "
            f"{format_minutes(values['minutes']):<10} "
            f"({values['sessions']} sessions)"
        )


def show_weekly_report(report):
    print("\n📈 LAST 7 DAYS")
    print("-" * 45)
    if not report:
        print("No data available.")
        return

    for item in report:
        bars = "█" * min(20, item["minutes"] // 30)
        print(f"{item['date']}  {bars:<20} {item['minutes']} min")
