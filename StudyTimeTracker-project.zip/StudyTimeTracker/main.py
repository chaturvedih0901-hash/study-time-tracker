from tracker import StudyTracker
from ui import (
    show_banner, show_menu, get_choice, get_subject,
    get_topic, show_message, show_summary, show_history,
    show_subject_stats, show_weekly_report, get_daily_goal
)
from storage import load_data


def main():
    tracker = StudyTracker()
    show_banner()

    while True:
        show_menu()
        choice = get_choice()

        if choice == "1":
            subject = get_subject()
            topic = get_topic()
            tracker.start_session(subject, topic)
            show_message("Study session started! Focus mode ON. 📚")

        elif choice == "2":
            session = tracker.stop_session()
            if session:
                show_message(
                    f"Session saved: {session['duration_minutes']} minutes."
                )
            else:
                show_message("No active session found.")

        elif choice == "3":
            show_summary(tracker.get_today_summary())

        elif choice == "4":
            show_history(tracker.get_history())

        elif choice == "5":
            show_subject_stats(tracker.get_subject_stats())

        elif choice == "6":
            goal = get_daily_goal()
            tracker.set_daily_goal(goal)
            show_message(f"Daily goal set to {goal} minutes. 🎯")

        elif choice == "7":
            show_weekly_report(tracker.get_weekly_report())

        elif choice == "8":
            show_message("Goodbye! Keep learning. 🚀")
            break


if __name__ == "__main__":
    main()
