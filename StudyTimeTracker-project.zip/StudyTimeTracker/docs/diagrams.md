# Diagrams

## High-Level Architecture

```text
+-------------+
|    User     |
+------+------+
       |
       v
+-------------+
|   main.py   |
+------+------+
       |
       v
+-------------+
|  tracker.py |
+------+------+
       |
       v
+-------------+
| storage.py  |
+------+------+
       |
       v
+----------------+
| sessions.json  |
+----------------+

ui.py handles menus, input and display.
```

## Session Workflow

```text
START
  |
  v
Choose Subject
  |
  v
Start Timer
  |
  v
Study
  |
  v
Stop Timer
  |
  v
Calculate Duration
  |
  v
Save Session
  |
  v
Display Statistics
```
