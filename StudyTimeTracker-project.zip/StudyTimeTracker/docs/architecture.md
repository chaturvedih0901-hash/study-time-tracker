# Study Time Tracker - Architecture

## Components

- `main.py`: application entry point and menu workflow.
- `tracker.py`: starts/stops sessions and calculates summaries.
- `storage.py`: reads and writes JSON data.
- `ui.py`: console menus, input validation, and output formatting.

## Data Flow

User -> main.py -> tracker.py -> storage.py -> sessions.json

Reports use data loaded from `sessions.json` and are formatted by `ui.py`.
