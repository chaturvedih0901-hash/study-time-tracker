# Study Time Tracker - Workflow

1. Launch `main.py`.
2. Select Start Study Session.
3. Enter subject and topic.
4. The application records the start timestamp.
5. Select Stop Study Session after studying.
6. The application calculates elapsed time.
7. The completed session is saved to JSON.
8. The user can view today's total, history, subject statistics, or weekly report.
9. The user can update the daily study goal at any time.
